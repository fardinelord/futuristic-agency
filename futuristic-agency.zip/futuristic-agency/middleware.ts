import { NextRequest, NextResponse } from 'next/server';

export function middleware(req: NextRequest) {
  const country = req.geo?.country || 'US'; // Fallback to 'US' if geo is unavailable
  const locale = country === 'IR' ? 'fa' : 'en';

  const { pathname } = req.nextUrl;

  if (pathname === '/') {
    const url = req.nextUrl.clone();
    url.pathname = `/${locale}/`; // Add trailing slash for consistency
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/'],
};